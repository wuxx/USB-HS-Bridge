#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "CH347SPILIB.h"

#define CMD_FLASH_SECTOR_ERASE 0x20
#define CMD_FLASH_BYTE_PROG    0x02
#define CMD_FLASH_READ         0x03
#define CMD_FLASH_RDSR         0x05
#define CMD_FLASH_WREN         0x06

#define CMD_FLASH_JEDEC_ID     0x9F

#define SPI_FLASH_PerWritePageSize 256

#ifndef CH34x_DEBUG
#define CH34x_DEBUG
#endif

#ifdef CH34x_DEBUG
#define dbg( format, arg...)	printf( format "\n", ##arg );
#endif
#define err( format, arg... )	\
	printf( "error %d: " format "\n", __LINE__, ##arg )

int dev_fd = -1;
BOOL FlashDevIsOpened = FALSE;
static struct timeval t1, t2;

BOOL CH347_SPI_init()
{
    BOOL ret = FALSE;
    StreamHwCfgS *StreamCfg = { 0 };
    mSpiCfgS spiDev = { 0 };    
    system("clear");
    // Open the device
    dev_fd = CH347OpenDevice(0);
    if (dev_fd < 0) {
        err("Failed to open device");
        return FALSE;
    }

    FlashDevIsOpened = TRUE;

    spiDev.iMode = 3;
    spiDev.iClock = 1;
    spiDev.iByteOrder = 1;
    spiDev.iSpiOutDefaultData = 0xFF;

    // Init CH347 SPI 
    ret = CH347SPI_Init(dev_fd, &spiDev);
    if (!ret) {
        err("Failed to init device");
        return FALSE;
    }

	// Init CH347 IIC
	ret = CH347I2C_Set(dev_fd, 3);	// The IIC speed set 750K
	if (!ret) {
		err("Failed to init I2C");
		return FALSE;
	}

    return TRUE;
}

ULONG EndSwitch(ULONG dwVal)
{
	ULONG SV;

	((PUCHAR)&SV)[0] = ((PUCHAR)&dwVal)[3];
	((PUCHAR)&SV)[1] = ((PUCHAR)&dwVal)[2];
	((PUCHAR)&SV)[2] = ((PUCHAR)&dwVal)[1];
	((PUCHAR)&SV)[3] = ((PUCHAR)&dwVal)[0];
	return SV;
}

BOOL FLASH_IC_Check()
{
    unsigned int count;
    unsigned int Flash_ID = 0;
    unsigned int dat = 0;
    unsigned int iLength = 0;

    UCHAR mBuffer[16] = { 0 };
    memset(mBuffer+1, 0xFF, 3);
    mBuffer[0] = CMD_FLASH_JEDEC_ID;
    iLength = 3;
    if (CH347SPI_WriteRead(dev_fd, 0x80, iLength + 1, mBuffer) == FALSE)
		return (0xFFFFFFFF);
	else
	{
		mBuffer[0] = 0;
		memcpy(&dat, mBuffer, 4);
	}

    Flash_ID = EndSwitch(dat);
    printf("  Flash_ID: %X\n", Flash_ID);
}

unsigned int FLASH_RD_Block(unsigned int address, UCHAR *pbuf, unsigned int len)
{
	/* W25系列FLASH、SST系列FLASH */
	ULONG iLen = 0;
	UCHAR DBuf[8192] = {0};

	DBuf[0] = CMD_FLASH_READ;
	DBuf[1] = (UCHAR)(address >> 16);
	DBuf[2] = (UCHAR)(address >> 8);
	DBuf[3] = (UCHAR)(address);

	iLen = len;
	if (!CH347SPI_Read(dev_fd, 0x80, 4, &iLen, DBuf))
	{
		printf("  FLASH_RD_Block %d bytes failure.");
		return 0;
	}
	else
	{
		memcpy(pbuf, DBuf, len);
		return len;
	}
}

// FLASH字节读
BOOL FlashBlockRead()
{
	double UseT;
	ULONG DataLen, FlashAddr = 0, i;
	UCHAR DBuf[8192] = {0};
	CHAR FmtStr[512] = "", FmtStr1[8 * 1024 * 3 + 16] = "";

	if (!FlashDevIsOpened)
	{
		printf("请先打开设备");
		return FALSE;
	}

	//获取FLASH读的起始地址
	FlashAddr = 0x00;
	//获取FLASH读的字节数,十六进制
	DataLen = 0x100;

	gettimeofday(&t1, NULL);
	DataLen = FLASH_RD_Block(FlashAddr, DBuf, DataLen);
	gettimeofday(&t2, NULL);

	int data_sec = t2.tv_sec - t1.tv_sec;
	int data_usec = t2.tv_usec - t1.tv_usec;

	UseT = ((float)data_sec + (float)data_usec / 1000000);

	if (DataLen < 1)
	{
		printf(">>Flash读:从[%X]地址开始读入%d字节...失败.\n", FlashAddr, DataLen);
	}
	else
	{
		printf(">>Flash读:从[%X]地址开始读入%d字节...成功.用时%.3fS\n", FlashAddr, DataLen, UseT);
		{ //显示FLASH数据,16进制显示
			for (i = 0; i < DataLen; i++)
				sprintf(&FmtStr1[strlen(FmtStr1)], "%02X ", DBuf[i]);
			printf("Read: %s\n", FmtStr1);
		}
	}
	return TRUE;
}

BOOL FLASH_WriteEnable()
{
	ULONG iLen = 0;
	UCHAR DBuf[128] = {0};

	DBuf[0] = CMD_FLASH_WREN;
	iLen = 0;
	return CH347SPI_WriteRead(dev_fd, 0x80, iLen + 1, DBuf);
}

BOOL CH34xFlash_Wait()
{
	ULONG mLen, iChipselect;
	UCHAR mWrBuf[3];
	UCHAR status;
	mLen = 3;
	iChipselect = 0x80;
	mWrBuf[0] = CMD_FLASH_RDSR;
	do{
		mWrBuf[0] = CMD_FLASH_RDSR;
		if( CH347StreamSPI4( dev_fd, iChipselect, mLen, mWrBuf ) == FALSE )
			return FALSE;		
		status = mWrBuf[1];
	}while( status & 1 );
	return true;
}

BOOL CH34xSectorErase(ULONG StartAddr )
{
	ULONG mLen, iChipselect;
	UCHAR mWrBuf[4];
	if( FLASH_WriteEnable(index) == FALSE )
		return FALSE;
	mWrBuf[0] = CMD_FLASH_SECTOR_ERASE;
	mWrBuf[1] = (UCHAR)( StartAddr >> 16 & 0xff );
	mWrBuf[2] = (UCHAR)( StartAddr >> 8 & 0xf0 );
	mWrBuf[3] = 0x00;
	mLen = 4;	
	iChipselect = 0x80;
	if( CH347StreamSPI4( dev_fd, iChipselect, mLen, mWrBuf ) == FALSE )
		return FALSE;

	if( CH34xFlash_Wait() == FALSE )
		return FALSE;
	return true;		
}

BOOL FlashBlockWrite()
{
    ULONG i = 0;
	ULONG iChipselect = 0x80;
	UCHAR mWrBuf[8192];
	ULONG DataLen, FlashAddr;
	UCHAR DBuf[8 * 1024 + 16] = {0};
	UCHAR FmtStr[8 * 1024 * 3 + 16] = "", ValStr[16] = "";
	double BT, UseT;

	//获取写FLASH的起始地址,十六进制
	FlashAddr = 0x00;
	//获取写FLASH的字节数,十六进制
	DataLen = 0;

	for (i = 0; i < 256; i++)
	{
		FmtStr[i] = 256 - i;
	}
	for (i = 0; i < 256; i++)
	{
		DBuf[DataLen] = FmtStr[i];
		DataLen++;
	}

	if( !FLASH_WriteEnable() )
		return FALSE;

	mWrBuf[0] = CMD_FLASH_BYTE_PROG;
	mWrBuf[1] = (UCHAR)(FlashAddr >> 16);
	mWrBuf[2] = (UCHAR)(FlashAddr >> 8);
	mWrBuf[3] = (UCHAR)FlashAddr;
	memcpy(&mWrBuf[4], DBuf, DataLen);
    DataLen += 4;

	if( CH347SPI_Write( dev_fd, iChipselect, DataLen, SPI_FLASH_PerWritePageSize+4,mWrBuf) == FALSE )
		return FALSE;
	memset( mWrBuf, 0, sizeof( UCHAR ) * DataLen );
	if( !CH34xFlash_Wait() )
		return FALSE;		

	if (DataLen < 1)
	{
		printf(">>Flash写:从[%X]地址开始写入%d字节...失败\n", FlashAddr, DataLen);
	}
	else
	{
		printf(">>Flash写:从[%X]地址开始写入%d字节...成功.用时%.3fS\n", FlashAddr, DataLen, UseT / 1000);
	}
	return TRUE;
}

BOOL EEPROM_Write()
{
	ULONG i = 0;
	ULONG DataLen = 0;
	UCHAR DBuf[8 * 1024 + 16] = {0};

	BOOL RetVal = FALSE;

	printf("ready to write.\n");
	for (i = 0; i <= 255; i++)
	{
		DBuf[i] = 255 - i;
		DataLen++;
	}
	
	printf("Write EEPROM data:\n");
	RetVal = CH347WriteEEPROM(dev_fd,ID_24C02,0x00,DataLen,DBuf);

	for (i = 0; i <= 255; i++)
	{
		printf("%02x ", DBuf[i]);
		if (((i+1) % 10) == 0) 
			putchar(10);
	}

	putchar(10);

	return RetVal;
}

BOOL EEPROM_Read()
{
	ULONG i = 0;
	ULONG DataLen = 256;
	UCHAR DBuf[8 * 1024 + 16] = {0};

	BOOL RetVal = FALSE;

	RetVal = CH347ReadEEPROM(dev_fd,ID_24C02,0,DataLen,DBuf);

	printf("Read EEPROM data:\n");
	for (i = 0; i < 255; i++)
	{
		printf("%02x ", DBuf[i]);
		if (((i+1) % 10) == 0) 
			putchar(10);
	}

	putchar(10);

	return RetVal;
}

int main()
{
    BOOL ret = FALSE;

    // Open the CH347 Device
    ret = CH347_SPI_init();
    if (!ret) {
        err("Failed to init CH347 SPI.");
        exit(-1);
    }
#if 0
    // Read the Flash ID
    ret = FLASH_IC_Check();
    if (!ret) {
        err("Failed to find flash");
        exit(-1);
    }

    // Read the Flash data
    ret = FlashBlockRead();
    if (!ret) {
        err("Failed to read flash");
        exit(-1);
    }

    // Erase the flash data
    ret = CH34xSectorErase(0x00);
    if (!ret) {
        err("Failed to erase flash");
        exit(-1);
    }

    // Write the flash data
    ret = FlashBlockWrite();
    if (!ret) {
        err("Failed to write flash");
        exit(-1);
    }

    // Read the Flash data
    ret = FlashBlockRead();
    if (!ret) {
        err("Failed to read flash");
        exit(-1);
    }
#endif 

	// EEPROM 
	ret = EEPROM_Read();
    if (!ret) {
        err("Failed to read eeprom");
        exit(-1);
    }

	ret = EEPROM_Write();
    if (!ret) {
        err("Failed to write eeprom");
        exit(-1);
    }

	ret = EEPROM_Read();
    if (!ret) {
        err("Failed to read eeprom");
        exit(-1);
    }

    // Close the CH347 Device
    if (CH347CloseDevice(dev_fd))
	{
		FlashDevIsOpened = FALSE;
		printf("Close device succesed\n");
	}

}