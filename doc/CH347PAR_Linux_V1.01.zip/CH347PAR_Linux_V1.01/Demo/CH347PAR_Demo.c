#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "CH347LIB.h"

#define CMD_FLASH_SECTOR_ERASE 0x20
#define CMD_FLASH_BYTE_PROG    0x02
#define CMD_FLASH_READ         0x03
#define CMD_FLASH_RDSR         0x05
#define CMD_FLASH_WREN         0x06

#define CMD_FLASH_JEDEC_ID     0x9F

#define SPI_FLASH_PerWritePageSize 256

#ifndef CH34x_DEBUG
#define CH34x_DEBUG
#endif

#ifdef CH34x_DEBUG
#define dbg( format, arg...)	printf( format "\n", ##arg );
#endif
#define err( format, arg... )	\
	printf( "error %d: " format "\n", __LINE__, ##arg )

int dev_fd = -1;
BOOL FlashDevIsOpened = false;
static struct timeval t1, t2;

BOOL CH347_SPI_Init()
{
    BOOL ret = false;
    mSpiCfgS spiDev = { 0 };    
    system("clear");

    // Init the SPI arg
    spiDev.iMode = 3;
    spiDev.iClock = 1;
    spiDev.iByteOrder = 1;
    spiDev.iSpiOutDefaultData = 0xFF;

    // Init CH347 SPI 
    ret = CH347SPI_Init(dev_fd, &spiDev);
    if (!ret) {
        err("Failed to init device");
        return false;
    }

    return true;
}

BOOL CH347_I2C_Init()
{
	int ret = -1;
	// Init CH347 I2C
	ret = CH347I2C_Set(dev_fd, 3);	// The IIC speed set 750K
	if (!ret) {
		err("Failed to init I2C");
		return false;
	}

	return true;
}

ULONG EndSwitch(ULONG dwVal)
{
	ULONG SV;

	((PUCHAR)&SV)[0] = ((PUCHAR)&dwVal)[3];
	((PUCHAR)&SV)[1] = ((PUCHAR)&dwVal)[2];
	((PUCHAR)&SV)[2] = ((PUCHAR)&dwVal)[1];
	((PUCHAR)&SV)[3] = ((PUCHAR)&dwVal)[0];
	return SV;
}

BOOL FLASH_IC_Check()
{
    unsigned int count;
    unsigned int Flash_ID = 0;
    unsigned int dat = 0;
    unsigned int iLength = 0;

    UCHAR mBuffer[16] = { 0 };
    memset(mBuffer+1, 0xFF, 3);
    mBuffer[0] = CMD_FLASH_JEDEC_ID;
    iLength = 3;
    if (CH347SPI_WriteRead(dev_fd, 0x80, iLength + 1, mBuffer) == false)
		return (0xFFFFFFFF);
	else
	{
		mBuffer[0] = 0;
		memcpy(&dat, mBuffer, 4);
	}

    Flash_ID = EndSwitch(dat);
    printf("  Flash_ID: %X\n", Flash_ID);
}

unsigned int FLASH_RD_Block(unsigned int address, UCHAR *pbuf, unsigned int len)
{
	/* W25系列FLASH、SST系列FLASH */
	ULONG iLen = 0;
	UCHAR DBuf[8192] = {0};

	DBuf[0] = CMD_FLASH_READ;
	DBuf[1] = (UCHAR)(address >> 16);
	DBuf[2] = (UCHAR)(address >> 8);
	DBuf[3] = (UCHAR)(address);

	iLen = len;
	if (!CH347SPI_Read(dev_fd, 0x80, 4, &iLen, DBuf))
	{
		printf("FLASH_RD_Block %ld bytes failure.", iLen);
		return 0;
	}
	else
	{
		memcpy(pbuf, DBuf, len);
		return len;
	}
}

// FLASH字节读
BOOL FlashBlockRead()
{
	double UseT;
	ULONG DataLen, FlashAddr = 0, i;
	UCHAR DBuf[8192] = {0};
	CHAR FmtStr[512] = "", FmtStr1[8 * 1024 * 3 + 16] = "";

	if (!FlashDevIsOpened)
	{
		printf("请先打开设备");
		return false;
	}

	//获取FLASH读的起始地址
	FlashAddr = 0x00;
	//获取FLASH读的字节数,十六进制
	DataLen = 0x500;

	gettimeofday(&t1, NULL);
	DataLen = FLASH_RD_Block(FlashAddr, DBuf, DataLen);
	gettimeofday(&t2, NULL);

	int data_sec = t2.tv_sec - t1.tv_sec;
	int data_usec = t2.tv_usec - t1.tv_usec;

	UseT = ((float)data_sec + (float)data_usec / 1000000);

	if (DataLen < 1)
	{
		printf(">>Flash读:从[%lX]地址开始读入%ld字节...失败.\n", FlashAddr, DataLen);
	}
	else
	{
		printf(">>Flash读:从[%lX]地址开始读入%ld字节...成功.用时%.3fS\n", FlashAddr, DataLen, UseT);
		{ //显示FLASH数据,16进制显示
			for (i = 0; i < DataLen; i++)
				sprintf(&FmtStr1[strlen(FmtStr1)], "%02X ", DBuf[i]);
			printf("Read: \n%s\n", FmtStr1);
		}
	}
	return true;
}

BOOL FLASH_WriteEnable()
{
	ULONG iLen = 0;
	UCHAR DBuf[128] = {0};

	DBuf[0] = CMD_FLASH_WREN;
	iLen = 0;
	return CH347SPI_WriteRead(dev_fd, 0x80, iLen + 1, DBuf);
}

BOOL CH34xFlash_Wait()
{
	ULONG mLen, iChipselect;
	UCHAR mWrBuf[3];
	UCHAR status;
	mLen = 3;
	iChipselect = 0x80;
	mWrBuf[0] = CMD_FLASH_RDSR;
	do{
		mWrBuf[0] = CMD_FLASH_RDSR;
		if( CH347StreamSPI4( dev_fd, iChipselect, mLen, mWrBuf ) == false )
			return false;		
		status = mWrBuf[1];
	}while( status & 1 );	
	return true;
}

BOOL CH34xSectorErase(ULONG StartAddr )
{
	ULONG mLen, iChipselect;
	UCHAR mWrBuf[4];
	if( FLASH_WriteEnable(index) == false )
		return false;
	mWrBuf[0] = CMD_FLASH_SECTOR_ERASE;
	mWrBuf[1] = (UCHAR)( StartAddr >> 16 & 0xff );
	mWrBuf[2] = (UCHAR)( StartAddr >> 8 & 0xf0 );
	mWrBuf[3] = 0x00;
	mLen = 4;	
	iChipselect = 0x80;
	if( CH347StreamSPI4( dev_fd, iChipselect, mLen, mWrBuf ) == false )
		return false;

	if( CH34xFlash_Wait() == false )
		return false;
	return true;		
}

BOOL W25XXX_WR_Page(PUCHAR pBuf, ULONG address, ULONG len)
{
	ULONG iChipselect = 0x80;
	UCHAR mWrBuf[8192];

	if( !FLASH_WriteEnable() )
			return false;
		
	mWrBuf[0] = CMD_FLASH_BYTE_PROG;
	mWrBuf[1] = (UCHAR)(address >> 16);
	mWrBuf[2] = (UCHAR)(address >> 8);
	mWrBuf[3] = (UCHAR)address;
	memcpy(&mWrBuf[4], pBuf, len);

	if( CH347SPI_Write( dev_fd, iChipselect, len+4, SPI_FLASH_PerWritePageSize+4,mWrBuf) == false )
		return false;
	memset( mWrBuf, 0, sizeof( UCHAR ) * len );
	if( !CH34xFlash_Wait() )
		return false;
}

BOOL FlashBlockWrite()
{
    ULONG i = 0;
	ULONG DataLen, FlashAddr, BeginAddr, NumOfPage, NumOfSingle;
	UCHAR DBuf[8 * 1024 + 16] = {0};
	UCHAR FmtStr[8 * 1024 * 3 + 16] = "", ValStr[16] = "";
	PUCHAR pbuf;
	double BT, UseT;

	//获取写FLASH的起始地址,十六进制
	FlashAddr = 0x00;
	BeginAddr = FlashAddr;
	//获取写FLASH的字节数,十六进制
	DataLen = 0;

	for (i = 0; i < 512; i++)
	{
		DBuf[i] = 0x55;
		DataLen++;
	}

	pbuf = DBuf;

	NumOfPage = DataLen / SPI_FLASH_PerWritePageSize;
	NumOfSingle = DataLen % SPI_FLASH_PerWritePageSize;

	gettimeofday(&t1, NULL);
	if (NumOfPage == 0)
	{
		W25XXX_WR_Page(DBuf, FlashAddr, DataLen);
	} else 
	{
		while (NumOfPage--)
		{
			W25XXX_WR_Page(pbuf, FlashAddr, SPI_FLASH_PerWritePageSize);
			pbuf += SPI_FLASH_PerWritePageSize;
			FlashAddr += SPI_FLASH_PerWritePageSize;
		}
		if (NumOfSingle)
			W25XXX_WR_Page(pbuf, FlashAddr, NumOfSingle);
	}
	gettimeofday(&t2, NULL);

	int data_sec = t2.tv_sec - t1.tv_sec;
	int data_usec = t2.tv_usec - t1.tv_usec;

	UseT = ((float)data_sec + (float)data_usec / 1000000);

	if (DataLen < 1)
	{
		printf(">>Flash写:从[%lX]地址开始写入%ld字节...失败\n", BeginAddr, DataLen);
	}
	else
	{
		printf(">>Flash写:从[%lX]地址开始写入%ld字节...成功.用时%.3fS\n", BeginAddr, DataLen, UseT / 1000);
	}
	return true;
}

BOOL EEPROM_Write()
{
	ULONG i = 0;
	ULONG DataLen = 0;
	UCHAR DBuf[8 * 1024 + 16] = {0};

	BOOL RetVal = false;

	printf("Ready to write.\n");
	for (i = 0; i <= 255; i++)
	{
		DBuf[i] = 255 - i;
		DataLen++;
	}
	
	printf("Write EEPROM data:\n");
	RetVal = CH347WriteEEPROM(dev_fd,ID_24C02,0x00,DataLen,DBuf);

	for (i = 0; i <= 255; i++)
	{
		printf("%02x ", DBuf[i]);
		if (((i+1) % 10) == 0) 
			putchar(10);
	}

	putchar(10);

	return RetVal;
}

BOOL EEPROM_Read()
{
	ULONG i = 0;
	ULONG DataLen = 256;
	UCHAR DBuf[8 * 1024 + 16] = {0};

	BOOL RetVal = false;

	RetVal = CH347ReadEEPROM(dev_fd,ID_24C02,0,DataLen,DBuf);
	
	printf("Read EEPROM data:\n");
	for (i = 0; i <= 255; i++)
	{
		printf("%02x ", DBuf[i]);
		if (((i+1) % 10) == 0) 
			putchar(10);
	}

	putchar(10);

	return RetVal;
}

static int get_menu()
{
	int choose = -1;
	printf("******************************************\n");
	printf("***   Enter Num Choose Funcation Test ****\n");
	printf("******************************************\n");
	printf("****          1 FLASH TEST            ****\n");
	printf("****          2 EEPROM TEST           ****\n");
	printf("****          3 JTAG TEST             ****\n");
	printf("****          4                       ****\n");
	printf("******************************************\n");
	printf("Your choose:\n");
	choose = getchar()-'0';
	getchar();
	return choose;
}

void FLASH_Test()
{
	int ret = -1;
    ret = CH347_SPI_Init();
    if (!ret) {
        err("Failed to init CH347 SPI.");
        exit(-1);
    }

    // Read the Flash ID
    ret = FLASH_IC_Check();
    if (!ret) {
        err("Failed to find flash");
        exit(-1);
    }

    // Read the Flash data
    ret = FlashBlockRead();
    if (!ret) {
        err("Failed to read flash");
        exit(-1);
    }

    // Erase the flash data
    ret = CH34xSectorErase(0x00);
    if (!ret) {
        err("Failed to erase flash");
        exit(-1);
    }

    // Write the flash data
    ret = FlashBlockWrite();
    if (!ret) {
        err("Failed to write flash");
        exit(-1);
    }

	// Check the flash data
   ret = FlashBlockRead();
    if (!ret) {
        err("Failed to read flash");
        exit(-1);
    }

	return;
}

void EEPROM_Test()
{
	int ret = -1;
	printf("Enter the EEPROM Test mode.\n");

	ret = CH347_I2C_Init();
    if (!ret) {
        err("Failed to init CH347 I2C.");
        exit(-1);
    }

	ret = EEPROM_Read();
    if (!ret) {
        err("Failed to read eeprom");
        exit(-1);
    }
	ret = EEPROM_Write();
    if (!ret) {
        err("Failed to write eeprom");
        exit(-1);
    }

	ret = EEPROM_Read();
    if (!ret) {
        err("Failed to read eeprom");
        exit(-1);
    }
}

void JTAG_Test()
{
	UCHAR retValue[32] = "";
	ULONG i, len = 32,cmd_len = 5;
	UCHAR IDCODE[4096] = "";	
	// Init the TCK clock
	CH347Jtag_INIT(dev_fd, 4);
	// Reset the Target
	CH347Jtag_SwitchTapState(dev_fd, 0);
	// SHIFT-DR Read the Target IDCODE
	CH347Jtag_ByteReadDR(dev_fd, &len, &retValue);
	
	printf("Target IDCODE: 0x");
	for (i = 0; i < 4; i++)
	{
		printf("%02x",retValue[3-i]);
	}
	puts("");
	return;
}

int main()
{
    BOOL ret = false;

	// Open the device
    dev_fd = CH347OpenDevice(0);
	// dev_fd = open("/dev/hidraw2", O_RDWR);
    if (dev_fd <= 0) {
        printf("Failed to open device.\n");
        return -1;
    }

    FlashDevIsOpened = true;
	while (1) {
		switch (get_menu())
		{
		case 1:
			printf("FLASH Test.\n");
			FLASH_Test();
			break;
		case 2:
			printf("EEPROM Test.\n");
			EEPROM_Test();
			break;
		case 3:
			printf("JTAG Test.\n");
			JTAG_Test();
			break;
		default:
			printf("Please enter the number[1/2/3].\n");
			break;
		}
	}

    // Close the CH347 Device
    if (CH347CloseDevice(dev_fd))
	{
		FlashDevIsOpened = false;
		printf("Close device succesed\n");
	}

	return 0;
}