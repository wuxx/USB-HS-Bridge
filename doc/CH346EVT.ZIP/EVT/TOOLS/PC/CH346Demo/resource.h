//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Main.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_Main                        107
#define IDI_SMALL                       108
#define IDC_PRAMFRAME                   109
#define IDD_SPI_Parallel_Demo           132
#define IDC_WORK_TYPE                   1000
#define IDC_ClearDbgShow                1005
#define IDC_TIMEOUT                     1008
#define IDC_DevList                     1011
#define IDC_TxPktLenS                   1016
#define IDC_RefreshDevList              1019
#define IDC_SendFilePath                1023
#define IDC_BrowseTxFile                1024
#define IDC_CLEAR_BUFF                  1038
#define IDC_DbgShow                     1039
#define IDC_WorkMode                    1040
#define IDC_SaveMode                    1042
#define IDC_SwithWorkMode               1043
#define IDC_EnableBufDown               1044
#define IDC_EnableBufUpload             1045
#define IDC_TxDataSel1                  1046
#define IDC_TxDataSel2                  1047
#define IDC_TxFilePath                  1048
#define IDC_TxDataSel0                  1049
#define IDC_RxFilePath                  1050
#define IDC_SelTxFile                   1051
#define IDC_StopTest                    1060
#define IDC_SaveInfor                   1063
#define IDC_OpenDevice                  1072
#define IDC_CloseDevice                 1073
#define IDC_Write                       1092
#define IDC_WriteData                   1094
#define IDC_ReadData                    1096
#define IDC_Read                        1097
#define IDC_BatchWrite                  1098
#define IDC_ResetTRxCnt                 1101
#define IDC_EnAutoRecvToFile            1102
#define IDC_BeginAutoRx                 1103
#define IDC_StopTxThread                1104
#define IDC_DevInfor                    1105
#define IDC_WriteLen                    1106
#define IDC_EnAutoRecvShow              1107
#define IDC_EnableRxDataCheck0          1108
#define IDC_EnablePnPAutoOpen           1109
#define IDC_PnPStatus                   1110
#define IDC_UploadBufPktSize            1111
#define IDC_RxStatistics                1112
#define IDC_TxStatistics                1113
#define IDC_DnPktCnt                    1114
#define IDC_ReadLen                     1121
#define IDC_ResetDevice                 1122

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
