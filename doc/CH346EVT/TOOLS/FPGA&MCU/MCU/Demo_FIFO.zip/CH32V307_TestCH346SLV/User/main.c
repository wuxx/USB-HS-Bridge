/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2021/06/06
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
#include "debug.h"
#include "stdlib.h"
#include "string.h"


/*******************************************************************************
 * MCU -  CH32V307VCT6, 120M��Ƶ, WR��RDʱ��Լ10M
 *
 * WR : MCU SLV����     ->  CH346 SLV ->    CH346 USB�ϴ�
 * RD : CH346 USB�´�   ->  CH346 SLV ->    MCU SLV����
 *
 * NOTE : SLV����DMAƫ�ƺͳ��Ƚ�������, ������DATA�߽Ӵ�, ����ƫ�ƺͳ���ʱƵ��̫��
 ******************************************************************************/

/******************************************************************************/
/* �����ú� */
/* ��һ�����ѡ�� */
//#define     EN_WR_ONLY    //  ֻд, ������Ҫ����WR���ݸ�ʽ�Լ�ÿ��WRʱ�İ����
#define     EN_WR_RD      //  �ȶ���д�ػ�

/* �ı�ػ����Ե�RD����ʽ : 0, 1 */
#define     HOST_RD_TYPE                1

/* �ػ�ģʽMCU��д�������� :  1,2,4,8,16,32,64...... */
#define     BLOCK_NUM                   1

/******************************************************************************/
/* CH346�����, ������16 */
#define     CH346_BLKNUM                16
#define     CH346_BLKMASK               (CH346_BLKNUM - 1)
#define     GET_REMAIN()                ( load - deal )
#define     GET_FREE()                  ( BLOCK_NUM - GET_REMAIN( ) )

/* CH346��д���� */
#define     DEF_CMD_SLV_PARA_WR         0xAA
#define     DEF_CMD_SLV_PARA_RD         0xBB

#define     RESET_RETRY_MAX             100

#define     REVERSE_ENDIAN(a) \
(uint32_t)({ \
    uint32_t _temp32 = a, res; \
    res = _temp32 >> 24; \
    res += (_temp32 & 0xFF0000) >> 8; \
    res += (_temp32 & 0xFF00) << 8; \
    res += (_temp32 & 0xFF) << 24; \
    res; \
})

/******************************************************************************/
typedef struct __packed {
    uint32_t    len;
    uint8_t     buf[512];
} slv_para_buf_t;

/* ���������ֱ�ά������д���Ե�ringbuffer, ��Ϊ516�ֽ� * 16��, �˴�����ػ�ģʽֻ����1�� */
__attribute__ ((aligned(4))) slv_para_buf_t para_t[ CH346_BLKNUM ];
/* load : RDָ��, deal : WRָ�� */
uint32_t load, deal;
/* �ػ�ģʽ��ǰ״̬ */
uint8_t RD0_WR1;

/******************************************************************************/
/* Ӳ������
   V307         CH346 SLV PARA
   PE0~PE7  -   DATA0~7
   PA0      -   CS
   PA1      -   RD
   PC1      -   WR
   PC2      -   A0
   PC3      -   RDNE
   PC4      -   WRNF */
#define     CS_HIGH()                   (GPIOA->BSHR = GPIO_Pin_0)
#define     CS_LOW()                    (GPIOA->BCR = GPIO_Pin_0)
#define     RD_HIGH()                   (GPIOA->BSHR = GPIO_Pin_1)
#define     RD_LOW()                    (GPIOA->BCR = GPIO_Pin_1)
#define     WR_HIGH()                   (GPIOC->BSHR = GPIO_Pin_1)
#define     WR_LOW()                    (GPIOC->BCR = GPIO_Pin_1)
#define     A0_HIGH()                   (GPIOC->BSHR = GPIO_Pin_2)
#define     A0_LOW()                    (GPIOC->BCR = GPIO_Pin_2)
#define     RDNE_IS_LO()                ((GPIOC->INDR & GPIO_Pin_3) == 0)
#define     WRNF_IS_LO()                ((GPIOC->INDR & GPIO_Pin_4) == 0)
#define     RDNE_IS_HI()                (GPIOC->INDR & GPIO_Pin_3)
#define     WRNF_IS_HI()                (GPIOC->INDR & GPIO_Pin_4)
#define     LED_HI()                    (GPIOC->BSHR = GPIO_Pin_0)
#define     LED_LO()                    (GPIOC->BCR = GPIO_Pin_0)

/*********************************************************************
 * @fn      Para_GPIO_Init
 *
 * @brief   IO��ʼ��
 *
 * @return  none
 */
void Para_GPIO_Init(void)
{
    GPIO_InitTypeDef Para_GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                           RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOE, ENABLE);

    Para_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    Para_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    Para_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &Para_GPIO_InitStructure);

    LED_HI( );
    Para_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
    Para_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    Para_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &Para_GPIO_InitStructure);

    Para_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;
    Para_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    Para_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &Para_GPIO_InitStructure);

    GPIO_SetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_1);
    GPIO_SetBits(GPIOC, GPIO_Pin_1 | GPIO_Pin_2);


    Para_GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 |
                                  GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 |
                                  GPIO_Pin_6 | GPIO_Pin_7;
    Para_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    Para_GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &Para_GPIO_InitStructure);
}

/*********************************************************************
 * @fn      Para_Host_Delay
 *
 * @brief   ����������ʱ
 *
 * @return  none
 */
void Para_Host_Delay( void )
{
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
}

/*********************************************************************
 * @fn      Para_Host_Write_CMD
 *
 * @brief   ��������д������, ʹ��WRʱ��, ����A0
 *
 * @return  none
 */
void Para_Host_Write_CMD( uint8_t cmd )
{
    /* ����IO������� */
    GPIOE->CFGLR = 0x33333333;
    /* �򲢿�������� */
    GPIOE->OUTDR = cmd;
    A0_HIGH();
    CS_LOW();

    Para_Host_Delay( );
    Para_Host_Delay( );

    WR_LOW();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    WR_HIGH();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    A0_LOW();
}

/*********************************************************************
 * @fn      Para_Host_Write_Data
 *
 * @brief   ��������д����, ʹ��WRʱ��, ������A0
 *
 * @return  none
 */
void Para_Host_Write_Data( uint8_t data )
{
    GPIOE->OUTDR = data;
    __NOP();__NOP();
    WR_LOW();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    WR_HIGH();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
    __NOP();__NOP();__NOP();__NOP();__NOP();
}

/*********************************************************************
 * @fn      Para_Host_Write_Data
 *
 * @brief   ��ƫ�Ƶ�ַ0, 1�ֽ�, ��ѯ��λ״̬
 *
 * @return  none
 */
void Para_Host_ResetOfs( void )
{
    uint8_t retry;
    uint8_t temp8;

    retry = 0;
    do
    {
        Para_Host_Write_CMD( DEF_CMD_SLV_PARA_RD );
        Para_Host_Write_Data( 0x00 );
        Para_Host_Write_Data( 0x00 );
        Para_Host_Write_Data( 0x01 );
        Para_Host_Write_Data( 0x00 );

        /* IO�л�������ģʽ */
        Para_Host_Delay( );
        GPIOE->CFGLR = 0x88888888;
        GPIOE->OUTDR = 0x00ff;

        RD_LOW();
        __NOP();__NOP();__NOP();__NOP();__NOP();
        RD_HIGH();
        __NOP();__NOP();__NOP();__NOP();__NOP();
        temp8 = (uint8_t)GPIOE->INDR;

        CS_HIGH();

        printf("%d : %d\n", retry, temp8);
        if( retry > 0 ) if( temp8 == 0 ) break;

        Delay_Ms( 10 );

        retry ++;
    }
    while( retry < RESET_RETRY_MAX );

    if( retry >= RESET_RETRY_MAX ) while( 1 );

    printf("ok\n");
}

/*********************************************************************
 * @fn      Para_Host_Read
 *
 * @brief   �ȷ���RD�������Լ�ƫ�ƺͳ���, Ȼ���4 + 512�ֽ�, ����4�ֽ�����ȷ����Ч���ݳ���
 *
 * @return  none
 */
void Para_Host_Read( void )
{
    uint32_t i;
    uint8_t *p;
    uint16_t ofs;
    uint16_t len;

    p = (uint8_t *)&(para_t[load & CH346_BLKMASK].len);
    ofs = (uint32_t)p - (uint32_t)(uint8_t *)para_t;
    len = 512;

    Para_Host_Write_CMD( DEF_CMD_SLV_PARA_RD );
    Para_Host_Write_Data( ofs );
    Para_Host_Write_Data( ofs >> 8 );
    Para_Host_Write_Data( len + 4 );
    Para_Host_Write_Data( (len + 4 ) >> 8 );

    /* IO�л�������ģʽ */
    Para_Host_Delay( );
    GPIOE->CFGLR = 0x88888888;
    GPIOE->OUTDR = 0x00ff;

    i = 0;
    while( i < 516 )
    {
        RD_LOW();
        RD_HIGH();
        p[ i ] = (uint8_t)GPIOE->INDR;
        i ++;
    }

    len = para_t[load & CH346_BLKMASK].len;
//    printf("    len %d\n", len);
//    p = para_t[load & CH346_BLKMASK].buf;
//    i = 0;
//    while( i < 512 )
//    {
//        RD_LOW();
//        RD_HIGH();
//        p[i] = (uint8_t)GPIOE->INDR;
//        i ++;
//    }

    CS_HIGH();
}

/*********************************************************************
 * @fn      Para_Host_Read4_First
 *
 * @brief   �ȷ���RD�������Լ�ƫ�ƺͳ���, Ȼ���4 �ֽ�, ����4�ֽڳ���ȷ����Ч���ݳ���
 *
 * @return  none
 */
void Para_Host_Read4_First( )
{
    uint32_t i;
    uint8_t *p;
    uint16_t ofs;
    uint16_t len;

    p = (uint8_t *)&(para_t[load & CH346_BLKMASK].len);
    ofs = (uint32_t)p - (uint32_t)(uint8_t *)para_t;
    len = 0;

    Para_Host_Write_CMD( DEF_CMD_SLV_PARA_RD );//cmd RD
    Para_Host_Write_Data( ofs );
    Para_Host_Write_Data( ofs >> 8 );
    Para_Host_Write_Data( len + 4 );
    Para_Host_Write_Data( (len + 4 ) >> 8 );

    /* IO�л�������ģʽ */
    Para_Host_Delay( );
    GPIOE->CFGLR = 0x88888888;
    GPIOE->OUTDR = 0x00ff;

    i = 0;
    while( i < (len+4) )
    {
        RD_LOW();
        RD_HIGH();
        p[ i ] = (uint8_t)GPIOE->INDR;
        i ++;
    }

    CS_HIGH();

    len = para_t[load & CH346_BLKMASK].len;

//    printf("    len %x\n", len);

#if 1

    if( len )
    {
        ofs += 4;
        p += 4;
        Para_Host_Write_CMD( DEF_CMD_SLV_PARA_RD );//cmd RD
        Para_Host_Write_Data( ofs );
        Para_Host_Write_Data( ofs >> 8 );
        Para_Host_Write_Data( len );
        Para_Host_Write_Data( (len ) >> 8 );

        //��Ҫ�������15������
        Para_Host_Delay( );

        GPIOE->CFGLR = 0x88888888;//�л�������ģʽ
        GPIOE->OUTDR = 0x00ff;

        i = 0;
        while( i < len )
        {
            RD_LOW();
            RD_HIGH();
            p[i] = (uint8_t)GPIOE->INDR;
            i ++;
        }

        CS_HIGH();
    }
#endif
}

/*********************************************************************
 * @fn      Para_Host_Write
 *
 * @brief   �ȷ���WR�������Լ�ƫ�ƺͳ���, Ȼ��д4 + len�ֽ�,
 *          len(len<=512)Ϊ��Ҫ�������ݳ���, ��Ҫ�ŵ�4�ֽ�����
 *
 * @return  none
 */
void Para_Host_Write( void )
{
    uint32_t i;
    uint8_t *p;
    uint16_t ofs;
    uint16_t len;

    p = (uint8_t *)&(para_t[deal & CH346_BLKMASK].len);
    ofs = (uint32_t)p - (uint32_t)(uint8_t *)para_t;
    len = para_t[deal & CH346_BLKMASK].len;

    Para_Host_Write_CMD( DEF_CMD_SLV_PARA_WR );
    Para_Host_Write_Data( ofs );
    Para_Host_Write_Data( ofs >> 8 );
    Para_Host_Write_Data( len + 4 );
    Para_Host_Write_Data( (len + 4 ) >> 8 );

    Para_Host_Delay( );

    i = 0;
    while( i < (len + 4) )
    {
        GPIOE->OUTDR = p[i];
        WR_LOW();
        WR_HIGH();
        i ++;
    }

    CS_HIGH();
}

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
    uint16_t i = 0;
    uint16_t j = 0;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_printf_Init(115200);
    printf("SystemClk:%d\n", SystemCoreClock);
    printf( "ChipID:%08x111111\n", DBGMCU_GetCHIPID() );

    Para_GPIO_Init( );

    memset(para_t, 0, sizeof(para_t));

    Para_Host_ResetOfs( );

    load = 0;
    deal = 0;
    RD0_WR1 = 0;

#ifdef EN_WR_ONLY
    /******************************************************************************/
    /* ֻдWR */

    printf("wr\r\n");

    /* WR���ݸ�ʽ, USB�ϴ�������λ��У�� */
    for(i = 0; i < CH346_BLKNUM; ++i)
    {
        para_t[i].len = 512;
        for(j = 4; j < para_t[i].len; ++j)
        {
            para_t[i].buf[j] = j - 4;
        }
    }

    while( 1 )
    {
        if( WRNF_IS_LO( ) )
        {
            *(uint32_t *)para_t[deal & CH346_BLKMASK].buf = REVERSE_ENDIAN(deal >> 4);
            Para_Host_Write( );

            deal ++;
        }
    }
#endif

#ifdef EN_WR_RD
    /******************************************************************************/
    /* �ػ�ģʽ */
    /* �ڶ��ռ����ʱRD�������л�ΪWR */
    /* ��д�ռ�ǿ�ʱWR, �����л�ΪRD */

    while( 1 )
    {
        /* ��RD */
        if( RD0_WR1 == 0 )
        {
            if( ( GET_FREE( ) > 0 ) && RDNE_IS_LO( ) )
            {
#if HOST_RD_TYPE==0
                Para_Host_Read( );
#else
                Para_Host_Read4_First( );
#endif

                if( para_t[load & CH346_BLKMASK].len & 0xFFFF )
                {
                    load ++;
//                    printf("load %d\n", load & CH346_BLKMASK);
                }
            }
            else if( GET_FREE( ) == 0 )
            {
                RD0_WR1 = 1;
                LED_HI( );
            }
        }

        /* дWR */
        else
        {
            if( ( GET_REMAIN( ) > 0 ) && WRNF_IS_LO( ) )
            {
                Para_Host_Write();
                deal ++;
//                printf("deal %d\n", deal & CH346_BLKMASK);
            }
            else if( GET_REMAIN( ) == 0 )
            {
                RD0_WR1 = 0;
                LED_LO( );
            }
        }
    }
#endif
}
