/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2025/01/20
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
#include "debug.h"
#include "stdlib.h"
#include "string.h"


/*******************************************************************************
 * MCU -  CH32V307VCT6
 *
 * WR : MCU SPI主机     ->  CH346 SPI ->    CH346 USB上传
 * RD : CH346 USB下传   ->  CH346 SPI ->    MCU SPI主机
 ******************************************************************************/

/******************************************************************************/
/* 可配置宏 */
/* 打开一项测试选项 */
#define     EN_WR_ONLY    //  只写, 可能需要更改WR数据格式以及每次WR时的包序号
//#define     EN_WR_RD      //  先读后写回环

/* 改变回环测试的RD读方式 : 0, 1, 2 */
#define     HOST_RD_TYPE            1

/* 配置MCU读写缓存大小 : 512 * 1,2,4,8,16,32,64...... */
#define     BUFFER_SIZE             ( 512 * 1 )

/******************************************************************************/
#define     BLOCK_SIZE              ( 512 )
#define     BLOCK_NUM               ( BUFFER_SIZE / BLOCK_SIZE )
#define     BLOCK_MASK              ( BLOCK_NUM - 1 )
#define     GET_REMAIN()            ( load - deal )
#define     GET_FREE()              ( BLOCK_NUM - GET_REMAIN( ) )

/* GPIO功能定义 */
#define     CS_LO()                 (GPIOB->BCR = GPIO_Pin_12)
#define     CS_HI()                 (GPIOB->BSHR = GPIO_Pin_12)
#define     LED_LO()                (GPIOC->BCR = GPIO_Pin_0)
#define     LED_HI()                (GPIOC->BSHR = GPIO_Pin_0)
#define     RWS_LO_RD()             ({GPIOD->BCR = GPIO_Pin_6; LED_LO( );})
#define     RWS_HI_WR()             ({GPIOD->BSHR = GPIO_Pin_6; LED_HI( );})
#define     WRNF_IS_HI()            (GPIOB->INDR & GPIO_Pin_0)
#define     RDNE_IS_HI()            (GPIOB->INDR & GPIO_Pin_1)
#define     CS_IS_HI()              (GPIOB->INDR & GPIO_Pin_12)
#define     WRNF_IS_LO()            ((GPIOB->INDR & GPIO_Pin_0) == 0)
#define     RDNE_IS_LO()            ((GPIOB->INDR & GPIO_Pin_1) == 0)
#define     CS_IS_LO()              ((GPIOB->INDR & GPIO_Pin_12) == 0)
#define     KEY_IS_LO()             ((GPIOA->INDR & GPIO_Pin_2) == 0)

/* SPI外设选择 */
#define     SPIx                    SPI2
#define     DMA_TX_CH               DMA1_Channel5
#define     DMA_RX_CH               DMA1_Channel4
#define     DMA_FLAG_TC_TX          DMA1_FLAG_TC5
#define     DMA_FLAG_TC_RX          DMA1_FLAG_TC4

#define     SPI_PSC_NUM(psc_reg)    ( 1 << ( (psc_reg) / 8 + 1 ) )

/******************************************************************************/
/* SPI时钟频率 */
uint32_t psc_tbl[] =
{
    SPI_BaudRatePrescaler_2,
    SPI_BaudRatePrescaler_4,
    SPI_BaudRatePrescaler_8,
    SPI_BaudRatePrescaler_16,
    SPI_BaudRatePrescaler_32,
//    SPI_BaudRatePrescaler_64,
//    SPI_BaudRatePrescaler_128,
//    SPI_BaudRatePrescaler_256,
};
uint8_t psc = 0;

/* 缓冲区定义 */
__attribute__ ((aligned (4))) uint8_t rxbuf[ BUFFER_SIZE ];
__attribute__ ((aligned (4))) uint8_t rxbbuf_516[ 516 ];
__attribute__ ((aligned (4))) uint32_t rxlen[ BLOCK_NUM ];
__attribute__ ((aligned (4))) uint8_t tempbuf[ BLOCK_SIZE * 2 ];
/* load : RD指针, deal : WR指针 */
uint32_t load, deal;

/* 回环模式读写状态 */
uint8_t RWS_WR1_RD0;
uint8_t RWS_WR1_RD0_last;

/*********************************************************************
 * @fn      FlowCtl_Init
 *
 * @brief   流控相关IO初始化
 *
 * @return  none
 */
void FlowCtl_Init( void )
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                           RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD , ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;      //  PB0 : WRNF,  PB1 : RDNE
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;                   //  KEY
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    RWS_HI_WR( );
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;                   //  RWS
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;                   //  LED
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/*********************************************************************
 * @fn      SPI_FullDuplex_Init
 *
 * @brief   SPI硬件初始化
 *
 * @param   psc - SPI分频系数选择.
 *
 * @return  none
 */
void SPI_FullDuplex_Init( uint32_t psc )
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    SPI_InitTypeDef  SPI_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);

    CS_HI( );
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;                   //  CS
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;                   //  SCK
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;                   //  MISO
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;                   //  MOSI
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
#if 0
    /* MODE0 */
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
#else
    /* MODE3 */
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
#endif
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = psc;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPIx, &SPI_InitStructure);

    SPI_Cmd(SPIx, ENABLE);

    if( psc == SPI_BaudRatePrescaler_2 )
    {
        SPIx->HSCR = 1;
    }
    SPIx->DATAR;

    RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA1, ENABLE );

    DMA_DeInit( DMA_TX_CH );
    DMA_DeInit( DMA_RX_CH );
}

/*********************************************************************
 * @fn      SPIx_TxRx_DMA_Init
 *
 * @brief   SPI DMA启动收发
 *
 * @param   pTxBuf - 发送指针
 *          Txlen - 发送长度
 *          pRxBuf - 接收指针
 *          Rxlen - 接收长度
 *
 * @return  none
 */
void SPIx_TxRx_DMA_Init( uint8_t *pTxBuf, uint16_t Txlen, uint8_t *pRxBuf, uint16_t Rxlen )
{
    /* 配置DMA并进行发送和接收 */
    SPI_Cmd( SPIx, DISABLE );

    SPIx->CTLR2 &= ~(SPI_I2S_DMAReq_Tx | SPI_I2S_DMAReq_Rx);

    /* DMA1 SPIx Tx */
    DMA_TX_CH->CFGR &= ~DMA_CFGR1_EN;
    DMA_TX_CH->MADDR = (u32)(pTxBuf);
    DMA_TX_CH->PADDR = (u32)&SPIx->DATAR;
    DMA_TX_CH->CNTR = Txlen;

    /* DMA1 SPIx Rx */
    DMA_RX_CH->CFGR &= ~DMA_CFGR1_EN;
    DMA_RX_CH->MADDR = (u32)(pRxBuf);
    DMA_RX_CH->PADDR = (u32)&SPIx->DATAR;
    DMA_RX_CH->CNTR = Rxlen;

    DMA_TX_CH->CFGR = 0x2090 | DMA_CFGR1_EN;
    DMA_RX_CH->CFGR = 0x2080 | DMA_CFGR1_EN;

    SPIx->CTLR2 |= SPI_I2S_DMAReq_Tx | SPI_I2S_DMAReq_Rx;
    DMA1->INTFCR = DMA_FLAG_TC_TX | DMA_FLAG_TC_RX;

    SPI_Cmd( SPIx, ENABLE );
}

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
    uint16_t temp16;
    uint16_t len;
    uint8_t *pTxbuf, *pRxbuf;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);
    printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );
    printf("RD type %d, psc %d\n", HOST_RD_TYPE, SPI_PSC_NUM(psc_tbl[ psc ]) );

    FlowCtl_Init();
    SPI_FullDuplex_Init( psc_tbl[ psc ] );

    load = 0;
    deal = 0;
    RWS_WR1_RD0 = 1;
    RWS_WR1_RD0_last = RWS_WR1_RD0;
    memset(rxlen, 0, sizeof(rxlen));
    memset(rxbbuf_516, 0, sizeof(rxbbuf_516));
    memset(tempbuf, 0xFF, sizeof(tempbuf));

#ifdef EN_WR_ONLY
    /* WR数据格式, USB上传后由上位机校验 */
    for(uint16_t i = 0; i < BLOCK_NUM; ++i)
    {
        rxlen[i] = BLOCK_SIZE;
        for(uint16_t j = 4; j < rxlen[i]; ++j)
        {
            rxbuf[i * BLOCK_SIZE + j] = j;
        }
    }

    Delay_Ms(2000);

    RWS_LO_RD( );
    Delay_Ms(10);
    RWS_HI_WR( );
    Delay_Ms(10);
#endif

    while( 1 )
    {
        /* 只写 */
#ifdef EN_WR_ONLY
        if( WRNF_IS_LO( ) )
        {
            CS_LO( );

            /* 生成包序号 */
            ((uint32_t *)rxbuf)[ (deal & BLOCK_MASK) * BLOCK_SIZE ] = deal;

            /* SPI收发 */
            pTxbuf = rxbuf;
            SPIx_TxRx_DMA_Init( pTxbuf, rxlen[deal & BLOCK_MASK], tempbuf, rxlen[deal & BLOCK_MASK] );
            while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                    ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
            while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );

            deal ++;

            CS_HI( );

//            printf("deal %d\n", deal);
        }
#endif

        /* 读写回环 */
#ifdef EN_WR_RD
        /* 在读空间充足时RD，否则切换为WR */
        /* 在写空间非空时WR, 否则切换为RD */
        if( RWS_WR1_RD0 == 0 )
        {
            /* 切换为RD */
            if( RWS_WR1_RD0_last != RWS_WR1_RD0 )
            {
                RWS_WR1_RD0_last = RWS_WR1_RD0;
                RWS_LO_RD( );

#if HOST_RD_TYPE == 0
                /* MCU做主机 */
                /* 如果此时已经为高, 会先拉低再拉高 */
                while( WRNF_IS_HI( ) );
                /* 切换RD时，WR拉高表示从机准备好 */
                while( WRNF_IS_LO( ) );
#else
                /* 非MCU主机, 可能无法及时读IO */
                Delay_Us(10);
#endif
//                printf("RD\n");
            }

            if( ( GET_FREE( ) > 0 ) && RDNE_IS_LO( ) )
            {
#if HOST_RD_TYPE == 0
                /* MCU做主机, 先读4字节长度, 再读数据 */
                CS_LO( );
                SPIx_TxRx_DMA_Init( tempbuf, 4, (uint8_t *)&rxlen[ load & BLOCK_MASK ], 4 );
                while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                        ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );

                len = *(uint16_t*)&rxlen[ load & BLOCK_MASK ];
                temp16 = *( (uint16_t*)&rxlen[ load & BLOCK_MASK ] + 1 );
                if( temp16 != len )
                {
                    printf("len err %d %d:\n", len, temp16);
                }
                else if( len )
                {
                    /* 根据长度读数据 */
                    pRxbuf = &rxbuf[ ( load & BLOCK_MASK ) * BLOCK_SIZE ];
                    SPIx_TxRx_DMA_Init( tempbuf, len, pRxbuf, len );
                    while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                            ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                    while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );

                    load ++;

                    /* RD读数据完毕, 从机的RDNE会拉高, 如果还有数据则继续拉低*/
                    /* MCU做主机, 可及时读流控 */
                    while(RDNE_IS_LO());
                }
                CS_HI( );

#elif HOST_RD_TYPE == 1
                /* 非MCU做主机, 无法单独控制CS, 每次读写完成CS会拉高, 先读4字节长度 */
                CS_LO( );
                SPIx_TxRx_DMA_Init( tempbuf, 4, (uint8_t *)&rxlen[ load & BLOCK_MASK ], 4 );
                while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                        ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );
                CS_HI( );

                len = *(uint16_t*)&rxlen[ load & BLOCK_MASK ];
                temp16 = *( (uint16_t*)&rxlen[ load & BLOCK_MASK ] + 1 );
                if( temp16 != len )
                {
                    printf("len err %x %x:\n", len, temp16);
                }
                else if( len )
                {
                    /* RD读长度完毕，从机的RDNE会拉高, 如果正常则继续拉低 */
//                    while(RDNE_IS_LO());
//                    while(RDNE_IS_HI());
                    /* 非MCU做主机, 使用延时代替 */
                    Delay_Us(10);

                    /* 根据长度读数据 */
                    CS_LO( );
                    SPIx_TxRx_DMA_Init( tempbuf, len + 4, rxbbuf_516, len + 4 );
                    while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                            ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                    while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );
                    CS_HI( );

                    pRxbuf = &rxbuf[ ( load & BLOCK_MASK ) * BLOCK_SIZE ];
                    memcpy(pRxbuf, rxbbuf_516 + 4, len );

                    load ++;

                    /* RD读数据完毕, 从机的RDNE会拉高, 如果还有数据则继续拉低*/
//                    while(RDNE_IS_LO());
                    /* 非MCU做主机, 使用延时代替 */
                    Delay_Us(10);
                }

#elif HOST_RD_TYPE == 2
                /* 非MCU做主机, 无法单独控制CS, 每次读写完成CS会拉高, 直接读516字节 */
                CS_LO( );
                SPIx_TxRx_DMA_Init( tempbuf, 516, rxbbuf_516, 516 );
                while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                        ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );
                CS_HI( );

                memcpy(&rxlen[ load & BLOCK_MASK ], rxbbuf_516, 4);
                len = *(uint16_t*)&rxlen[ load & BLOCK_MASK ];
                temp16 = *( (uint16_t*)&rxlen[ load & BLOCK_MASK ] + 1 );

                if( temp16 != len )
                {
                    printf("len err %x %x:\n", len, temp16);
                }
                else if( len )
                {
                    pRxbuf = &rxbuf[ ( load & BLOCK_MASK ) * BLOCK_SIZE ];
                    memcpy(pRxbuf, rxbbuf_516 + 4, len );

                    load ++;

                    /* RD读数据完毕, 从机的RDNE会拉高, 如果还有数据则继续拉低*/
//                    while(RDNE_IS_LO());
                    /* 非MCU主机, 由于每次读516字节, 延时应已足够 */
                }
#endif
//                printf("load %d\n", load);
            }
            else
            {
                /* 读数据满则切换为WR状态 */
                if( GET_FREE( ) == 0 )
                {
                    RWS_WR1_RD0 = 1;
                }
            }
        }
        else
        {
            /* 切换为WR */
            if( RWS_WR1_RD0_last != RWS_WR1_RD0 )
            {
                RWS_WR1_RD0_last = RWS_WR1_RD0;
                /* 必须主机先切换为WR，从机才会拉低WRNF */
                RWS_HI_WR( );
//                printf("WR\n");
            }

            if( WRNF_IS_LO( ) )
            {
                if( ( GET_REMAIN( ) > 0 ) )
                {
                    CS_LO( );
                    pTxbuf = &rxbuf[ ( deal & BLOCK_MASK ) * BLOCK_SIZE ];
                    SPIx_TxRx_DMA_Init( pTxbuf, *(uint16_t*)&rxlen[ deal & BLOCK_MASK ],
                                        tempbuf + BLOCK_SIZE, *(uint16_t*)&rxlen[ deal & BLOCK_MASK ] );
                    while( ( ( DMA1->INTFR & DMA_FLAG_TC_TX ) == 0 ) &&
                            ( ( DMA1->INTFR & DMA_FLAG_TC_RX ) == 0 ) );
                    while( SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_BSY) != RESET );

                    deal ++;

                    CS_HI( );
//                    printf("    deal %d\n", deal);
                }
                else
                {
                    /* 只有RDNE为低时才切换为RD状态 */
                    if( RDNE_IS_LO( ) )
                    {
                        RWS_WR1_RD0 = 0;
                    }
                }
            }
        }
#endif

        /* 切换SPI频率 */
        /* 也可通过切换系统主频实现SPI不同频率 */
        if( KEY_IS_LO( ) )
        {
            Delay_Ms(1);
            if( KEY_IS_LO( ) )
            {
                CS_HI( );
                psc ++;
                if( psc >= ( sizeof(psc_tbl) / sizeof(psc_tbl[0]) ) )
                {
                    psc = 0;
                }

                SPI_FullDuplex_Init( psc_tbl[ psc ] );
                printf("RD type %d, psc %d\n", HOST_RD_TYPE, SPI_PSC_NUM(psc_tbl[ psc ]) );

                Delay_Ms(500);
            }
        }
    }
}
